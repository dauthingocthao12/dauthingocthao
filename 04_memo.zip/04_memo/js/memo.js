"use strict";
//ページ本体が読みこまれたタイミングで実行するコード
window.addEventListener("DOMContentLoaded",
 function(){
     //1.localStorageが使えるか確認
     if(typeof localStorage ==="undefined"){
     window.alert("このプラウザはLocal Storage 機能が実装されていません");
     return ;
    }else{
     viewStorage();      //localStorageからのデータ取得とデータルへ表示
     saveLocalStorage();//2.localStorageへ保存
    }
 } 
);
//2.localStorageへ保存
function saveLocalStorage(){
    const save=document.getElementById("save");
    save.addEventListener("click",
    function(e){
        e.preventDefault();
        const key=document.getElementById("textKey").value;
        const value=document.getElementById("textMemo").value;

        //値の入力チェック
        if (key =="" ||　value==""){
            window.alert("Key,Memoはいずれも必須　です");
            return;
        }else{
            localStorage.setItem(key,value);
            viewStorage();      //localStorageからのデータ取得とデータルへ表示
            let w_msg="LocalStorgaeに"+key+" "+value+"を保存しました";
            window.alert(w_msg);
            document.getElementById("textKey").value="";
            document.getElementById("textMemo").value="";
        }
    },false
 );
};
//localStorageからのデータの取得とデータルへ表示
function viewStorage(){
    const list=document.getElementById("list");
    //htmlのデータ初期化
    while(list.rows[0]) list.deleteRow(0);
////localStorageすべての情報の取得
 for(let i=0; i<localStorage.length;i++) {
     let w_key=localStorage.key(i);
     //localStorageのきーと値を表示
     let tr=document.createElement("tr");
     let td1=document.createElement("td");
     let td2=document.createElement("td");
     let td3=document.createElement("td");
     list.appendChild(tr);
     tr.appendChild(td1);
     tr.appendChild(td2);
     tr.appendChild(td3);

    td1.innerHTML="<input name='radio1' type='radio'>";
    td2.innerHTML=w_key;
    td3.innerHTML=localStorage.getItem(w_key);
 
}

}


